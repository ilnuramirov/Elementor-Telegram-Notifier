<?php
/**
 * Plugin Name: Elementor Telegram Notifier
 * Description: Добавляет действие "Send to Telegram" в формы Elementor с выводом URL и заголовка страницы.
 * Version: 1.1
 */

if ( ! defined( 'ABSPATH' ) ) exit;

function register_telegram_action_for_elementor( $actions ) {
    require_once( __DIR__ . '/telegram-action.php' );
    $actions->register( new Elementor_Telegram_Action() );
}
add_action( 'elementor_pro/forms/actions/register', 'register_telegram_action_for_elementor' );

<?php
use ElementorPro\Modules\Forms\Classes\Action_Base;
use ElementorPro\Modules\Forms\Classes\Form_Record;

class Elementor_Telegram_Action extends Action_Base {

    public function get_name() {
        return 'telegram';
    }

    public function get_label() {
        return 'Send to Telegram';
    }

    public function register_settings_section( $widget ) {
        $widget->start_controls_section(
            'section_telegram',
            [
                'label' => 'Telegram',
                'condition' => [ 'submit_actions' => $this->get_name() ],
            ]
        );

        $widget->add_control(
            'telegram_token',
            [
                'label' => 'Bot Token',
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'placeholder' => '123456:ABC-DEF...',
            ]
        );

        $widget->add_control(
            'telegram_chat_ids',
            [
                'label' => 'Chat ID(s)',
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'placeholder' => '123456789,-100987654321',
                'description' => 'Введите один или несколько chat ID через запятую',
            ]
        );

        $widget->end_controls_section();
    }

    public function run( $record, $ajax_handler ) {
        $settings = $record->get( 'form_settings' );
        $fields = $record->get( 'fields' );

        $token = trim( $settings['telegram_token'] );
        $chat_ids = array_map( 'trim', explode( ',', $settings['telegram_chat_ids'] ) );

        $message = "✉️ Новая заявка\n\n";

        foreach ( $fields as $id => $field ) {
            $title = !empty($field['title']) ? $field['title'] : $id;
            $value = $field['value'];

            if ($value === 'on' && preg_match('/field_[a-z0-9]+/i', $id)) {
                $message .= "🔒 Согласие на обработку: ✅ Да\n";
            }
            elseif ( stripos($title, 'имя') !== false ) {
                $message .= "👤 $title: $value\n";
            }
            elseif ( stripos($title, 'телефон') !== false ) {
                $message .= "📞 $title: $value\n";
            }
            elseif ( stripos($title, 'запрос') !== false || stripos($title, 'сообщение') !== false ) {
                $message .= "📝 $title: $value\n";
            }
            else {
                $message .= "$title: $value\n";
            }
        }

        if ( isset($_SERVER['HTTP_REFERER']) ) {
            $referer_url = esc_url_raw($_SERVER['HTTP_REFERER']);
            $post_id = url_to_postid($referer_url);

            if ($post_id) {
                $page_title = get_the_title($post_id);
                if ($page_title) {
                    $message .= "🌐 Тип заявки: $page_title\n";
                }
            }

            $message .= "🔗 URL: $referer_url\n";
        }

        foreach ( $chat_ids as $chat_id ) {
            $url = "https://api.telegram.org/bot{$token}/sendMessage";
            wp_remote_post( $url, [
                'body' => [
                    'chat_id' => $chat_id,
                    'text'    => $message,
                ],
            ]);
        }
    }

    public function on_export( $element ) {}
}
